<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    
    <link rel="stylesheet" href="css/services.css">
    

</head>
<body>

    <img src="images/img4.jpg" alt="car picture">
    <h2>  CAR INSURANCE</h2>
    <h3>
        ✔️ 6800+ Cashless Garages Network
    </h3>
    <h3>
        ✔️ Upto 70%^ OFF on Premium 
    </h3>
    <h3>
        ✔️ Overnight Repair Service
    </h3>
    <h3>
        ✔️ Immediate Claim Settlement For Minor Damages 
    </h3>
    <h3>
    <h3>
        ✔️ 50% Car Claims Settled Same Day
    </h3>

    <img src="images/img5.jpg" alt="Motor picture">
    <h2>  TWO WHEELER INSURANCE</h2>
    <h3>
        ✔️ Premium Starting At Just ₹482*
    </h3>
    <h3>
        ✔️ No Inspection & Zero Documentation
    </h3>
    <h3>
        ✔️ Immediate Claim Settlement For Minor Damages
    </h3>
    <h3> 
        ✔️ 3 Year Insurance at ₹1446°  
    </h3>
    <h3>
        ✔️ Doorstep Repair Service
    </h3>
    <img src="images/img7.jpg" alt="Doctor picture">
    <h2>  HEALTH INSURANCE</h2>
    <h3>
        ✔️ No Room Rent Capping
    </h3>
    <h3>
        ✔️ Cashless Home Healthcare
    </h3>
    <h3>
        ✔️ Free Health Check-ups On Renewal
    </h3>
    <h3> 
        ✔️ No Medical Test Upto 45 Years  
    </h3>
    <h3> 
        ✔️ 90% Reimbursement Settlement Within 7 days
    </h3>
 
    <img src="images/img8.jpg" alt="Airplane picture">
    <h2>  TRAVEL INSURANCE</h2>
    <h3>
        ✔️ 24/7 Worlwide Assistance
    </h3>
    <h3>
        ✔️ Covers Flight Delay
    </h3>
    <h3>
        ✔️ Covers Emergency Medical Expenses
    </h3>
    <h3> 
        ✔️ Covers Loss Of Baggage And Passport
    </h3>
    <h3> 
        ✔️ Sum Insured upto $500,000
    </h3>
    <img src="images/img9.jpg" alt="House picture">
    <h2>  HOME INSURANCE</h2>
    <h3>
        ✔️ Starts at Rs. 250*
    </h3>
    <h3>
        ✔️ Covers Loss/damage by Fire $ Natural Calamities
    </h3>
    <h3>
        ✔️ Alternate accomodation expenses** covered
    </h3>
    <h3> 
        ✔️ Covers Loss Of Baggage And Passport
    </h3>
    <h3> 
        ✔️ Covers Electrical Breakdown of home appliances
    </h3>
    
</body>
</html>