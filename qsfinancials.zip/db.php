<?php

$con=mysqli_connect("Localhost","admin","Xeallad@1919","payment");
