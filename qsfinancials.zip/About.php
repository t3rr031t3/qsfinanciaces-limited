<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    
    <link rel="stylesheet" href="{% static 'css/About.css' %}">

</head>
<body>
    <img src="images/img11.jpg" alt="logo">
    
    <h3>
        We are driven to provide insurance solutions to customers, Qsfinancials  Insurance has secured over #1.3 Crore+ customers. Right from offering comprehensive car insurance to a wide range of health insurance plans, we at Qsfinancials always take a Customer First Approach. Our plethora of offerings mainly include car insurance, two wheeler insurance, home insurance, travel insurance, health insurance and other commercial products. Backed by a super strong customer support team and seamless service driven claims operation, we ensure 360 degree customer happiness.
    </h3>
    
</body>
</html>