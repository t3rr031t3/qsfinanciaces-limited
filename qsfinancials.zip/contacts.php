<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    
    
    <link rel="stylesheet" href="css/contacts.css ">
</head>
<body>
    <img src="images/img13.jpg" alt="man making a phone call">

    <h2>CONTACT US :</h2>
    <h3>EMAIL:Info@qsfinancials.com</h3>
    <h3>PHONE NUMBER:+918200129466</h3>
    
</body>
</html>